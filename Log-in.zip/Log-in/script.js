document.addEventListener('DOMContentLoaded', function() {
    const form = document.querySelector('form');

    form.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent form submission for now

        // Get form inputs
        const firstName = document.querySelector('input[name="first-name"]').value.trim();
        const lastName = document.querySelector('input[name="last-name"]').value.trim();
        const email = document.querySelector('input[name="email"]').value.trim();
        const password = document.querySelector('input[name="password"]').value;
        const confirmPassword = document.querySelector('input[name="confirm-password"]').value;

        // Validation
        if (firstName === '' || lastName === '' || email === '' || password === '' || confirmPassword === '') {
            alert('Please fill in all fields.');
            return;
        }

        if (password !== confirmPassword) {
            alert('Password and Confirm Password must match.');
            return;
        }

        // If all validations pass, you can submit the form or perform further actions
        alert('Registration successful!');
        // form.submit(); // Uncomment this line to submit the form
    });
});
